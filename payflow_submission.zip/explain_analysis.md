# EXPLAIN analysis (duoi 200 tu)

Truy van cu dung YEAR(created_at) va MONTH(created_at) trong WHERE. Vi ham duoc ap dung len cot created_at, dieu kien ngay thang khong SARGable voi index B-Tree thong thuong, nen MySQL co the phai quet nhieu dong; EXPLAIN co the hien type = ALL khi khong co index phu hop.

Truy van moi thay hai ham bang khoang thoi gian nua mo: created_at >= '2026-06-01 00:00:00' AND created_at < '2026-07-01 00:00:00'. Index ket hop idx_type_date(transaction_type, created_at) loc theo transaction_type truoc, sau do tim khoang created_at. Ke hoach moi co the dung type = range va hien idx_type_date o cot key, giam so dong can doc.

Gia tri type va rows cu the phu thuoc du lieu, phan bo gia tri, phien ban MySQL va optimizer; can chup EXPLAIN truoc/sau tren cung mot CSDL de xac nhan, khong nen tu dien ket qua.
