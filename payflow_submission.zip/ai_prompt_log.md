# AI prompt log: Index va SARGable

1. Prompt: Trong MySQL, tai sao WHERE YEAR(created_at) = 2026 va MONTH(created_at) = 6 co the khong dung duoc B-Tree index tren created_at?
   Tom tat: Ap dung ham len cot khien dieu kien khong SARGable theo cach thong thuong. Doi sang khoang ngay nua mo de optimizer co the tim range tren index.

2. Prompt: Index ket hop (transaction_type, created_at) nen sap xep cot the nao?
   Tom tat: Thu tu cot quan trong. Dieu kien bang (=) tren transaction_type dat truoc, dieu kien khoang tren created_at dat sau, phu hop voi leftmost-prefix cua composite index.

3. Prompt: EXPLAIN type = ALL, range va ref co nghia gi?
   Tom tat: ALL thuong la quet toan bang; range la truy cap mot khoang index; ref la tra cuu index theo gia tri khong duy nhat. Day la cac dang truy cap, khong phai cam ket thoi gian tuyet doi.

4. Prompt: Using index condition khac Using index nhu the nao?
   Tom tat: Using index condition cho biet Index Condition Pushdown duoc ap dung; Using index thuong chi ra truy van duoc phuc vu tu index (covering index), khong can doc them dong bang cho cac cot duoc chon.

5. Prompt: Them nhieu index co anh huong gi den bang co INSERT/UPDATE/DELETE nhieu khong?
   Tom tat: Moi index can duoc cap nhat khi du lieu thay doi, lam tang chi phi ghi, dung bo nho va dung luong dia. Chi nen tao index phuc vu truy van co gia tri.
