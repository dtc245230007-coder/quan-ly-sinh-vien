-- PAYFLOW: TOI UU TRUY VAN BANG EXPLAIN VA INDEX
-- MySQL 8.x
CREATE DATABASE IF NOT EXISTS payflow_db;
USE payflow_db;

-- Bang mau theo de bai. Neu bang Transactions da ton tai, khong can tao lai.
CREATE TABLE IF NOT EXISTS Transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(15,2),
    transaction_type VARCHAR(20),
    created_at DATETIME
);

-- 1. EXPLAIN truy van cu (Non-SARGable).
-- Neu chua co du lieu/index phu, truy van nay co the quet toan bang.
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND YEAR(created_at) = 2026
  AND MONTH(created_at) = 6;

-- 2. Tao composite B-Tree index.
CREATE INDEX idx_type_date
ON Transactions (transaction_type, created_at);

-- 3. EXPLAIN truy van moi: dieu kien ngay thang dang SARGable.
EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at <  '2026-07-01 00:00:00';

-- 4. Chay truy van moi de lay ket qua bao cao.
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at <  '2026-07-01 00:00:00';

-- LUU Y:
-- EXPLAIN rows/type la uoc tinh cua optimizer, khong phai so lieu cam ket.
-- Can chay tren du lieu that de chup ket qua truoc/sau.
-- CREATE INDEX se bao loi neu idx_type_date da ton tai; neu da co index,
-- hay bo qua lenh CREATE INDEX hoac kiem tra SHOW INDEX FROM Transactions.
